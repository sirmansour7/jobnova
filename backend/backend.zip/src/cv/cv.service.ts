import {
  BadRequestException,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { RulesAnalysisProvider } from './analysis/rules-analysis.provider';
import { OpenAiAnalysisProvider } from './analysis/openai-analysis.provider';
import type { CvAnalysisResult } from './analysis/cv-analysis.types';

@Injectable()
export class CvService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
    private readonly rulesProvider: RulesAnalysisProvider,
    private readonly openAiProvider: OpenAiAnalysisProvider,
  ) {}

  async getMyCv(userId: string) {
    return this.prisma.cv.findUnique({
      where: { userId },
    });
  }

  async upsertMyCv(userId: string, body: unknown) {
    const contentJson = this.normalizeContent(body);

    const cv = await this.prisma.cv.upsert({
      where: { userId },
      create: {
        userId,
        contentJson,
      },
      update: {
        contentJson,
      },
    });

    return cv;
  }

  async analyzeMyCv(userId: string): Promise<CvAnalysisResult> {
    const cv = await this.prisma.cv.findUnique({
      where: { userId },
    });

    if (!cv) {
      throw new BadRequestException('CV not found for this user. Please save your CV first.');
    }

    const providerKey = (this.config.get<string>('CV_ANALYSIS_PROVIDER') ?? 'rules').toLowerCase();
    const version = this.config.get<number>('CV_ANALYSIS_VERSION') ?? 1;

    const provider = this.getProvider(providerKey);
    const analysis = await provider.analyze(cv.contentJson);

    await this.prisma.cv.update({
      where: { userId },
      data: {
        analysisJson: analysis,
        analysisProvider: provider.name,
        analysisVersion: version,
        analysisUpdatedAt: new Date(),
      },
    });

    return analysis;
  }

  private normalizeContent(body: unknown): Record<string, any> {
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
      throw new BadRequestException('Body must be an object or { contentJson: object }.');
    }

    const obj = body as Record<string, any>;

    if ('contentJson' in obj) {
      const value = obj.contentJson;
      if (!value || typeof value !== 'object' || Array.isArray(value)) {
        throw new BadRequestException('contentJson must be a non-null object.');
      }
      return value as Record<string, any>;
    }

    return obj;
  }

  private getProvider(providerKey: string) {
    if (providerKey === 'openai') {
      const apiKey = this.config.get<string>('OPENAI_API_KEY');
      if (!apiKey) {
        throw new InternalServerErrorException(
          'CV analysis provider "openai" requires OPENAI_API_KEY to be set in the environment.',
        );
      }
      return this.openAiProvider;
    }

    // Default to rules-based provider
    if (providerKey !== 'rules') {
      throw new InternalServerErrorException(
        `Unsupported CV analysis provider "${providerKey}". Supported providers: "rules", "openai".`,
      );
    }

    return this.rulesProvider;
  }
}

