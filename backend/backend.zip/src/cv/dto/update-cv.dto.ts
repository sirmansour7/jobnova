export class UpdateCvDto {
  // Intentionally minimal; validation is handled dynamically in the service
  // to support both `{ contentJson: object }` and direct object payloads.
  contentJson?: Record<string, any>;
}

