import type { CvAnalysisResult } from './cv-analysis.types';

export interface CvAnalysisProvider {
  name: string;
  analyze(content: any): Promise<CvAnalysisResult>;
}

