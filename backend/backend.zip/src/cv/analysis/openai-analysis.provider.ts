import { Injectable } from '@nestjs/common';
import type { CvAnalysisResult } from './cv-analysis.types';
import type { CvAnalysisProvider } from './cv-analysis.provider';

@Injectable()
export class OpenAiAnalysisProvider implements CvAnalysisProvider {
  name = 'openai';

  // Stub implementation — real integration will be added later.
  async analyze(_content: any): Promise<CvAnalysisResult> {
    throw new Error('OpenAI CV analysis provider is not implemented yet.');
  }
}

