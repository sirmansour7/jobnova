import { Injectable } from '@nestjs/common';
import type { CvAnalysisResult } from './cv-analysis.types';
import type { CvAnalysisProvider } from './cv-analysis.provider';

@Injectable()
export class RulesAnalysisProvider implements CvAnalysisProvider {
  name = 'rules';

  async analyze(content: any): Promise<CvAnalysisResult> {
    const normalized = this.normalizeContent(content);

    const strengths: string[] = [];
    const gaps: string[] = [];
    const suggestedImprovements: string[] = [];
    const atsNotes: string[] = [];

    const hasSummary = this.hasSummary(normalized);
    const experienceCount = this.getExperienceCount(normalized);
    const skillsCount = this.getSkillsCount(normalized);
    const hasLinks = this.hasLinks(normalized);

    let score = 50;

    if (hasSummary) {
      score += 15;
      strengths.push('Has a clear professional summary/headline.');
    } else {
      gaps.push('Missing a concise professional summary at the top of the CV.');
      suggestedImprovements.push('Add a 2–4 line professional summary that highlights your core value, years of experience, and key skills.');
    }

    if (experienceCount >= 3) {
      score += 20;
      strengths.push('Includes multiple experience entries, showing career progression.');
    } else if (experienceCount >= 1) {
      score += 10;
      strengths.push('Includes at least one relevant experience entry.');
      gaps.push('Consider expanding your experience section with more roles or responsibilities.');
      suggestedImprovements.push('Add more details to your experience section, including context, responsibilities, and outcomes.');
    } else {
      gaps.push('No work experience section detected.');
      suggestedImprovements.push('Add a work experience section with company, role, dates, and 3–6 bullet points per role.');
    }

    if (skillsCount >= 10) {
      score += 15;
      strengths.push('Strong skills section with a wide range of competencies.');
    } else if (skillsCount >= 5) {
      score += 8;
      strengths.push('Skills section detected with several relevant skills.');
      gaps.push('Skills section could be expanded for better keyword coverage.');
      suggestedImprovements.push('Add more specific technical and domain skills that match your target roles.');
    } else if (skillsCount > 0) {
      gaps.push('Skills section is quite short.');
      suggestedImprovements.push('List more skills, grouped by category (e.g. Languages, Frameworks, Tools, Soft Skills).');
    } else {
      gaps.push('No clear skills section detected.');
      suggestedImprovements.push('Add a dedicated skills section with 10–20 relevant hard and soft skills.');
    }

    if (hasLinks) {
      score += 10;
      strengths.push('Includes links (e.g. LinkedIn, GitHub, portfolio) for extra context.');
    } else {
      gaps.push('No professional links (LinkedIn, GitHub, portfolio) detected.');
      suggestedImprovements.push('Add links to your LinkedIn, GitHub, portfolio, or relevant profiles in the header or contact section.');
    }

    const metricNotes = this.detectMissingMetrics(normalized);
    if (metricNotes.length > 0) {
      gaps.push('Many bullet points seem to lack measurable impact (numbers, percentages, or clear outcomes).');
      suggestedImprovements.push(
        'Rewrite key bullets to include metrics (e.g. “Increased conversion by 15%”, “Reduced processing time by 30%”, “Handled 50+ customers per day”).',
      );
      atsNotes.push(...metricNotes);
    }

    const keywordSuggestions = this.suggestKeywordsForRole(normalized);
    const keywordsMissing = keywordSuggestions.missing;
    if (keywordsMissing.length > 0) {
      suggestedImprovements.push(
        'Incorporate relevant role-specific keywords naturally into your summary, experience, and skills sections.',
      );
      atsNotes.push('Add important keywords from job descriptions to improve ATS matching.');
    }

    score = Math.max(0, Math.min(100, score));

    if (score >= 80) {
      atsNotes.push('Overall CV structure looks strong for ATS and recruiter screening.');
    } else if (score >= 60) {
      atsNotes.push('CV is solid but can be improved with clearer impact and more targeted keywords.');
    } else {
      atsNotes.push('CV needs significant improvement in structure, impact, and keyword coverage.');
    }

    return {
      score,
      strengths,
      gaps,
      keywordsMissing,
      suggestedImprovements,
      atsNotes,
    };
  }

  private normalizeContent(content: any): any {
    if (!content || typeof content !== 'object' || Array.isArray(content)) {
      return {};
    }
    return content;
  }

  private hasSummary(content: any): boolean {
    const profile = content.profile ?? {};
    const summary = profile.summary ?? profile.about ?? content.summary ?? content.objective;
    return typeof summary === 'string' && summary.trim().length > 0;
  }

  private getExperienceArray(content: any): any[] {
    if (Array.isArray(content.experience)) return content.experience;
    if (Array.isArray(content.experiences)) return content.experiences;
    if (Array.isArray(content.work)) return content.work;
    if (Array.isArray(content.jobs)) return content.jobs;
    return [];
  }

  private getExperienceCount(content: any): number {
    return this.getExperienceArray(content).length;
  }

  private getSkillsArray(content: any): any[] {
    if (Array.isArray(content.skills)) return content.skills;
    if (Array.isArray(content.technicalSkills)) return content.technicalSkills;
    if (Array.isArray(content.softSkills)) return content.softSkills;
    return [];
  }

  private getSkillsCount(content: any): number {
    const skills = this.getSkillsArray(content);
    if (!skills.length) return 0;
    return skills
      .map((s) => {
        if (typeof s === 'string') return 1;
        if (s && typeof s === 'object') {
          if (Array.isArray(s.items)) return s.items.length;
          if (typeof s.name === 'string') return 1;
        }
        return 0;
      })
      .reduce((a, b) => a + b, 0);
  }

  private hasLinks(content: any): boolean {
    const links =
      content.links ??
      content.urls ??
      content.profiles ??
      content.social ??
      content.contact?.links ??
      content.contact?.urls ??
      [];

    if (Array.isArray(links) && links.length > 0) return true;

    const header = content.header ?? content.profile ?? content.contact;
    if (header && typeof header === 'object') {
      const possible = [header.linkedin, header.github, header.portfolio, header.website];
      return possible.some((v) => typeof v === 'string' && v.trim().length > 0);
    }

    return false;
  }

  private detectMissingMetrics(content: any): string[] {
    const experience = this.getExperienceArray(content);
    const notes: string[] = [];

    const bullets: string[] = [];
    for (const item of experience) {
      if (!item || typeof item !== 'object') continue;
      if (Array.isArray(item.bullets)) bullets.push(...item.bullets);
      if (Array.isArray(item.responsibilities)) bullets.push(...item.responsibilities);
      if (Array.isArray(item.achievements)) bullets.push(...item.achievements);
    }

    const plainBullets = bullets.filter((b) => typeof b === 'string' && b.trim().length > 0);
    const withoutMetrics = plainBullets.filter((b) => !this.hasMetric(b));

    if (withoutMetrics.length === 0) return notes;

    const sample = withoutMetrics.slice(0, 3);
    for (const bullet of sample) {
      const snippet = bullet.length > 120 ? `${bullet.slice(0, 117)}...` : bullet;
      notes.push(`Consider adding metrics to bullet: "${snippet}"`);
    }

    return notes;
  }

  private hasMetric(text: string): boolean {
    if (!text) return false;
    const hasNumber = /\d/.test(text);
    const hasPercentOrPlus = /[%+]/.test(text);
    const hasQuantWords = /(increased|decreased|reduced|improved|grew|boosted|cut|saved|raised|achieved)/i.test(
      text,
    );
    return hasNumber && (hasPercentOrPlus || hasQuantWords);
  }

  private suggestKeywordsForRole(content: any): { missing: string[] } {
    const profile = content.profile ?? {};
    const rawTitle: string =
      profile.title ??
      profile.headline ??
      content.title ??
      content.targetRole ??
      content.role ??
      '';

    if (typeof rawTitle !== 'string' || rawTitle.trim().length === 0) {
      return { missing: [] };
    }

    const title = rawTitle.toLowerCase();

    let targetKeywords: string[] = [];

    if (title.includes('software') || title.includes('developer') || title.includes('engineer')) {
      targetKeywords = [
        'javascript',
        'typescript',
        'node.js',
        'react',
        'api',
        'rest',
        'testing',
        'unit tests',
        'integration tests',
        'ci/cd',
        'design patterns',
        'clean code',
      ];
    } else if (title.includes('data') && (title.includes('scientist') || title.includes('analyst'))) {
      targetKeywords = [
        'python',
        'sql',
        'statistics',
        'machine learning',
        'pandas',
        'numpy',
        'visualization',
        'dashboard',
        'experiments',
        'ab testing',
      ];
    } else if (title.includes('product manager')) {
      targetKeywords = [
        'roadmap',
        'stakeholders',
        'requirements',
        'user research',
        'prioritization',
        'metrics',
        'experiments',
        'a/b testing',
        'okrs',
        'backlog',
      ];
    } else if (title.includes('designer') || title.includes('ux') || title.includes('ui')) {
      targetKeywords = [
        'user research',
        'wireframes',
        'prototypes',
        'figma',
        'usability testing',
        'design system',
        'accessibility',
        'interaction design',
        'visual design',
      ];
    } else {
      targetKeywords = ['results', 'impact', 'stakeholders', 'collaboration', 'leadership', 'ownership'];
    }

    const textBlob = JSON.stringify(content).toLowerCase();
    const missing = targetKeywords.filter((kw) => !textBlob.includes(kw.toLowerCase()));

    return { missing };
  }
}

