export type CvAnalysisResult = {
  score: number;
  strengths: string[];
  gaps: string[];
  keywordsMissing: string[];
  suggestedImprovements: string[];
  atsNotes: string[];
};

